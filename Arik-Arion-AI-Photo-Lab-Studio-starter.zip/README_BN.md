# Arik & Arion AI Photo Lab Studio

এটি Android Studio-তে খোলার জন্য একটি প্রাথমিক Android project scaffold। এটি এখনো পূর্ণাঙ্গ photo editor নয় এবং এই ZIP-এ তৈরি APK নেই।

## এই ধাপের অবস্থা
- অ্যাপের নাম ও Android package পরিচয় সেট করা হয়েছে
- একটি প্রাথমিক Android UI shell যোগ করা হয়েছে
- পরের ধাপে ছবি import, crop/rotate, layers, masks, এবং Gemini AI integration আলাদাভাবে যোগ ও পরীক্ষা করতে হবে

## গুরুত্বপূর্ণ
Gemini API key কখনো GitHub-এ বা APK-এর ভিতরে সরাসরি লিখবেন না। AI feature নিরাপদভাবে যুক্ত করার জন্য পরে backend/API proxy দরকার হবে।
