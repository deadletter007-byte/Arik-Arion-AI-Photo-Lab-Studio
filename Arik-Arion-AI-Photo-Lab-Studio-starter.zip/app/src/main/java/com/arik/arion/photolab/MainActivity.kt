package com.arik.arion.photolab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF070A16)
private val Cyan = Color(0xFF25D9FF)
private val Violet = Color(0xFF9B5CFF)
private val Pink = Color(0xFFFF4FCB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoLabHome() }
    }
}

@Composable
fun PhotoLabHome() {
    val tools = listOf(
        "AI Photo Edit" to Icons.Default.AutoAwesome,
        "Layers & Mask" to Icons.Default.Layers,
        "Pen Tool & Path" to Icons.Default.Gesture,
        "Background Blur" to Icons.Default.BlurOn,
        "Object Removal" to Icons.Default.AutoFixHigh,
        "Crop & Resize" to Icons.Default.Crop,
        "Undo / Redo" to Icons.Default.Undo,
        "Import Photo" to Icons.Default.AddPhotoAlternate
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Color(0xFF11182B),
        primary = Cyan, secondary = Violet
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            Column(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(58.dp).background(
                            Brush.linearGradient(listOf(Cyan, Violet, Pink)),
                            RoundedCornerShape(17.dp)
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                    Spacer(Modifier.width(13.dp))
                    Column {
                        Text("Arik & Arion", fontSize = 23.sp, fontWeight = FontWeight.Bold,
                            color = Color.White)
                        Text("AI Photo Lab Studio", fontSize = 13.sp, color = Cyan)
                    }
                }
                Text("Your creative photo workspace", color = Color.LightGray, fontSize = 15.sp)
                Button(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Violet),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Start Editing", fontSize = 16.sp)
                }
                Text("TOOLS", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(tools) { item ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF11182B)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.height(112.dp)
                        ) {
                            Column(
                                Modifier.fillMaxSize().padding(14.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.Start
                            ) {
                                Icon(item.second, null, tint = if (item.first.contains("AI")) Pink else Cyan,
                                    modifier = Modifier.size(28.dp))
                                Spacer(Modifier.height(10.dp))
                                Text(item.first, color = Color.White, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
                Text(
                    "Starter build • Editing tools are being added step by step",
                    color = Color.Gray, fontSize = 11.sp
                )
            }
        }
    }
}
